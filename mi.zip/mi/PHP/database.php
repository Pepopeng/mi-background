<?php

 $link=mysqli_connect('localhost:3306','root','root') or die("数据库连接失败");
 mysqli_query($link,"set names gbk");
 mysqli_query($link,"use mi");




?>