<?php


   header('Content-Type:application/json');

   include_once '../PHP/database.php';
   $tables=['item_phone','item_wear','item_wear1','item_laptop',
   'item_household0','item_household',
   'item_cook0','item_cook1','item_cook2','item_cook3',
   'item_daily0','item_daily1','item_daily2','item_daily3',
   'item_life0','item_life1','item_life2','item_life3',
   'item_smart0','item_smart1','item_smart2','item_smart3',
   'item_sports0','item_sports1','item_sports2','item_sports3'];//每个元素都是一个表


   foreach ($tables as $value) {
       $res=mysqli_query($link,"select * from {$value}");
       while($row = mysqli_fetch_assoc($res)){ // loop to store the data in an associative array.
             if($row['text1']) $row['text1']=iconv('GBK','UTF-8',$row['text1']);
             if($row['text2']) $row['text2']=iconv('GBK','UTF-8',$row['text2']);
             if($row['price']) $row['price']=iconv('GBK','UTF-8',$row['price']);
             if($row['old_price']) $row['old_price']=iconv('GBK','UTF-8',$row['old_price']);
              $json[$value][] = $row;
         }
   }

   $res=mysqli_close($link);

//    $json['data'] = ["code", "msg" ];
//    $json['count']=5;
  // var_dump($json);
   echo json_encode($json,JSON_UNESCAPED_UNICODE);




?>