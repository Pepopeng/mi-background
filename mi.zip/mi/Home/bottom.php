<?php

   header('Content-Type:application/json');

   $butt=[
     [
         [
                   'text'=>'预约维修服务',
                   'a'=>'https://www.mi.com/service/quick-repair'
         ],
         [
                   'text'=>'7天无理由退货',
                   'a'=>'https://www.mi.com/service/exchange#back' 
         ],
         [
                   'text'=>'15天免费换货',
                   'a'=>'https://www.mi.com/service/exchange#back'
         ],
         [
                    'text'=>'满69包邮',
                    'a'=>'https://www.mi.com/service/buy/Postal%20policy'
         ],
          [
                    'text'=>'520余家售后网点',
                    'a'=>'https://www.mi.com/service/sitelist' 
          ]

     ],
     [
             [
                     [
                               'text'=>'账户管理',
                               'a'=>'https://www.mi.com/service/account/Account%20registration/' 
                     ],
                     [
                               'text'=>'购物指南',
                               'a'=>'https://www.mi.com/service/buy/SalesTime/' 
                     ],
                     [
                               'text'=>'订单操作',
                               'a'=>'https://www.mi.com/service/order/sendprogress/' 
                     ]
              ],
                [
                                   [
                                             'text'=>'售后政策',
                                             'a'=>'https://www.mi.com/service/exchange' 
                                   ],
                                   [
                                             'text'=>'自助服务',
                                             'a'=>'https://www.mi.com/service/' 
                                   ],
                                   [
                                             'text'=>'相关下载',
                                             'a'=>'https://www.mi.com/service/download/' 
                                   ]
                ],
                [
                                   [
                                             'text'=>'小米之家',
                                             'a'=>'https://www.mi.com/service/mihome/list' 
                                   ],
                                   [
                                             'text'=>'服务网点',
                                             'a'=>'https://www.mi.com/service/sitelist' 
                                   ],
                                   [
                                             'text'=>'授权体验店/专区',
                                             'a'=>'https://www.mi.com/service/family-location' 
                                   ]
                            ],
                [
                                   [
                                             'text'=>'了解小米',
                                             'a'=>'https://www.mi.com/about/' 
                                   ],
                                   [
                                             'text'=>'加入小米',
                                             'a'=>'https://hr.xiaomi.com/' 
                                   ],
                                   [
                                             'text'=>'投资者关系',
                                             'a'=>'https://company.mi.com/zh-cn/ir/indexContent/index.html' 
                                   ],
                                   [
                                             'text'=>'企业社会责任',
                                             'a'=>'https://www.mi.com/csr/' 
                                   ],
                                   [
                                             'text'=>'廉洁举报',
                                             'a'=>'https://www.mi.com/integrity' 
                                   ]
                            ],
                            [
                                   [
                                             'text'=>'新浪微博',
                                             'a'=>'https://weibo.com/xiaomishangcheng' 
                                   ],
                                   [
                                             'text'=>'官方微信',
                                             'a'=>'' 
                                   ],
                                   [
                                             'text'=>'联系我们',
                                             'a'=>'https://www.mi.com/about/contact' 
                                   ],
                                   [
                                             'text'=>'公益基金会',
                                             'a'=>'https://www.mi.com/foundation/index' 
                                   ]

                            ],
                            [
                                   [
                                             'text'=>'F码通道',
                                             'a'=>'https://www.mi.com/order/fcode' 
                                   ],
                                   [
                                             'text'=>'礼物码',
                                             'a'=>'https://www.mi.com/order/giftcode' 
                                   ],
                                   [
                                             'text'=>'防伪查询',
                                             'a'=>'https://www.mi.com/service/imei' 
                                   ]

                            ]



     ]
   ];

   $siteInfo=[
        [
             'text'=>'小米商城',
             'a'=>'' 
        ],
        [
             'text'=>'MIUI',
             'a'=>'https://www.miui.com/' 
        ],
         [
                     'text'=>'米家',
                     'a'=>'https://home.mi.com/index.html' 
         ],
                [
                     'text'=>'米聊',
                     'a'=>'http://www.miliao.com/' 
                ],
                [
                      'text'=>'多看',
                      'a'=>'https://www.duokan.com/' 
                 ],
                 [
                      'text'=>'游戏',
                      'a'=>'https://game.xiaomi.com/' 
                 ],
                  [
                              'text'=>'政企服务',
                              'a'=>'https://b.mi.com/?client_id=180100031058&masid=17409.0358' 
                  ],
                         [
                              'text'=>'小米天猫店',
                              'a'=>'https://xiaomi.tmall.com/' 
                         ],
                [
                           'text'=>'小米集团隐私政策',
                           'a'=>'https://privacy.mi.com/all/zh_CN/' 
                      ],
                      [
                           'text'=>'小米公司儿童信息保护规则',
                           'a'=>'https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/f516fe9e2c01.html' 
                      ],
                       [
                                   'text'=>'小米商城隐私政策',
                                   'a'=>'https://m.mi.com/support/module?id=63&headless=1' 
                       ],
                              [
                                   'text'=>'小米商城用户协议',
                                   'a'=>'https://www.mi.com/aptitude/list?id=62' 
                              ],
                              [
                                    'text'=>'问题反馈',
                                    'a'=>'https://static.mi.com/feedback/' 
                               ],
                               [
                                    'text'=>'Select Location',
                                    'a'=>'' 
                               ],
                                [
                                            'text'=>'北京互联网法院法律服务工作站',
                                            'a'=>'http://www.mi.com/beihu' 
                                ],
                                       [
                                            'text'=>'中国消费者协会',
                                            'a'=>'http://www.cca.org.cn/' 
                                       ],
                  [
                                                            'text'=>'北京市消费者协会',
                                                            'a'=>'http://www.bj315.org/' 
                                                       ]
   ];





$json['butt']=$butt;
$json['siteInfo']=$siteInfo;

//    $json['data'] = ["code", "msg" ] 
//    $json['count']=5 
  // var_dump($json) 
   echo json_encode($json,JSON_UNESCAPED_UNICODE) 




?>