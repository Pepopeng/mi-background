<?php

    //var_dump($_POST);

    include_once '../PHP/database.php';
    if($_POST["type"]=="1"){
        $res=mysqli_query($link,"Insert into user(name,password) values('".$_POST["account"]."','".$_POST["password"]."')");
        //var_dump("Insert into user(name,password) values('".$_POST["account"]."','".$_POST["password"]."')");
        if($res){
            var_dump('创建用户成功');
        }
        else{
            var_dump('创建用户失败');
        }
    }
    else{
        $res=mysqli_query($link,"select * from user where name='".$_POST["account"]."'");
           while($row = mysqli_fetch_assoc($res)){ // loop to store the data in an associative array.

                     if($row['password']==$_POST["password"]){
                        var_dump('登陆成功');
                        die();
                     }

                 }


        var_dump('用户名或密码错误');

    }

   $res=mysqli_close($link);

?>